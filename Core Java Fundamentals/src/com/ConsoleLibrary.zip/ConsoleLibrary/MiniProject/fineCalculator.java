package com.ConsoleLibrary.MiniProject;

public interface fineCalculator {
	
	//FineCalculator fine = days -> days * 2.0; // ₹2 per day fine
	double calculateFine(int daysLate);

}

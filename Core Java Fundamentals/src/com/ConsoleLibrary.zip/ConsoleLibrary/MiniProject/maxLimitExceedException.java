package com.ConsoleLibrary.MiniProject;

public class maxLimitExceedException extends Exception{

	public maxLimitExceedException(String message) {
		super(message);
	}
}

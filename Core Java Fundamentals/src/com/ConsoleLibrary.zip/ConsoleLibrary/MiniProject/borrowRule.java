package com.ConsoleLibrary.MiniProject;

public interface borrowRule {
	
	boolean canBorrow(member m, book b);

}

package com.ConsoleLibrary.MiniProject;

public class booksNotAvailableException extends Exception{
	
	public booksNotAvailableException(String message){
		super(message);
	}

}

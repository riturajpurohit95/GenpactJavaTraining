package com.ConsoleLibrary.MiniProject;

public class invalidReturnException extends Exception{
	
	public invalidReturnException(String message) {
		super(message);
	}

}

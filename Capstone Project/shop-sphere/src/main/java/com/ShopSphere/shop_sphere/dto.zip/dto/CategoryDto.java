package com.ShopSphere.shop_sphere.dto;

import jakarta.validation.constraints.NotBlank;

public class CategoryDto {
	
	public CategoryDto(Integer categoryId, @NotBlank(message = "Category name is required") String name,
			String description) {
		super();
		this.categoryId = categoryId;
		this.name = name;
		this.description = description;
	}
	private Integer categoryId;
	@NotBlank(message="Category name is required")
	private String name;
	private String description;
	public Integer getCategoryId() {
		return categoryId;
	}
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	

}

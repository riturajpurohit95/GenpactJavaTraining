package com.ShopSphere.shop_sphere.repository;

import java.util.List;

import com.ShopSphere.shop_sphere.model.Product;

public interface ProductDao {
	
	int save(Product product);
	Product findById(int productId);
	List<Product> findAll();
	List<Product> findByCategory(int categoryId);
	List<Product> findBySeller(int userId);
	int update(Product product);
	int delete(int productId);

}

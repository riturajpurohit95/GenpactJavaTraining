package com.ShopSphere.shop_sphere.repository;

import java.util.List;
import java.util.Optional;

import com.ShopSphere.shop_sphere.model.Product;

public interface ProductDao {
	
	int save(Product product);
	Optional<Product> findById(int productId);
	List<Product> findAll();
	Optional<Product> findByCategory(int categoryId);
	List<Product> findBySeller(int userId);
	List<Product> searchByName(String name);
	int update(Product product);
	int deleteById(int productId);

}

package com.ShopSphere.shop_sphere.repository;

import java.util.List;

import com.ShopSphere.shop_sphere.model.Order;

public interface OrderDao {
	
	int save(Order order);
	Order findById(int orderId);
	List<Order> findByUserId(int userId);
	int updateStatus(int orderId, String status);

}

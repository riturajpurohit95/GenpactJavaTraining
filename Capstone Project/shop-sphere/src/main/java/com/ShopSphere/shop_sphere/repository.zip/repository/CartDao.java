package com.ShopSphere.shop_sphere.repository;

import com.ShopSphere.shop_sphere.model.Cart;

public interface CartDao {
	
	int createCart(int userId);
	Cart findByUserId(int userId);

}

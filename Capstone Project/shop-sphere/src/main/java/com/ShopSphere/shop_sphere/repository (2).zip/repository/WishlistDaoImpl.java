package com.ShopSphere.shop_sphere.repository;

import com.ShopSphere.shop_sphere.model.Wishlist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
public class WishlistDaoImpl implements WishlistDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public WishlistDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // -------- RowMapper --------
    private static final RowMapper<Wishlist> WISHLIST_ROW_MAPPER = new RowMapper<Wishlist>() {
        @Override
        public Wishlist mapRow(ResultSet rs, int rowNum) throws SQLException {
            Wishlist w = new Wishlist();
            w.setWishlistId(rs.getInt("wishlist_id"));
            w.setUserId(rs.getInt("user_id"));
            return w;
        }
    };

    
    private static final String INSERT_SQL ="INSERT INTO wishlists (user_id) VALUES (?)";

    private static final String SELECT_BY_USER_ID_SQL ="SELECT wishlist_id, user_id FROM wishlists WHERE user_id = ?";

    @Override
    public int createWishlist(int userId) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        try {
            int affected = jdbcTemplate.update(con -> {
                PreparedStatement ps = con.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS);
                ps.setInt(1, userId);
                return ps;
            }, keyHolder);

            if (affected > 0 && keyHolder.getKey() != null) {
                return keyHolder.getKey().intValue();
            }
        } catch (DuplicateKeyException dke) {
            // If you have a unique index on user_id (recommended), return the existing wishlist
            Wishlist existing = findByUserId(userId);
            if (existing != null) {
                return existing.getWishlistId();
            }
        }

        // If insertion didn't return a key (or no unique constraint), try to fetch by user_id
        Wishlist fallback = findByUserId(userId);
        return (fallback != null) ? fallback.getWishlistId() : 0;
    }

    @Override
    public Wishlist findByUserId(int userId) {
        try {
            return jdbcTemplate.queryForObject(SELECT_BY_USER_ID_SQL, WISHLIST_ROW_MAPPER, userId);
        } catch (EmptyResultDataAccessException ex) {
            return null;
        }
    }
}

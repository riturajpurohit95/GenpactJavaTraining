package com.ShopSphere.shop_sphere.repository;

import java.util.List;

import com.ShopSphere.shop_sphere.model.OrderItem;

public interface OrderItemDao {
	
	int save(OrderItem item);
	List<OrderItem> findByOrderId(int orderId);

}

package com.ShopSphere.shop_sphere.repository;

import java.sql.PreparedStatement;
import java.sql.Statement;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.ShopSphere.shop_sphere.model.Cart;
import com.ShopSphere.shop_sphere.util.CartRowMapper;

@Repository
public class CartDaoImpl implements CartDao{
	
	private final JdbcTemplate jdbcTemplate;
	
	public CartDaoImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public int createCart(int userId) {
		String sql = "INSERT INTO carts (user_id) VALUES (?)";
		
		KeyHolder keyHolder = new GeneratedKeyHolder();
				
		jdbcTemplate.update(connection ->{
			PreparedStatement ps = connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
				ps.setInt(1, userId);
				return ps;
			}, keyHolder);
		
		return keyHolder.getKey().intValue();
	}

	@Override
	public Cart findByUserId(int userId) {
		String sql = "SELECT cart_id, user_id FROM carts WHERE user_id=?";
		
		return jdbcTemplate.queryForObject(sql, new CartRowMapper(), userId);
	}

}

package com.ShopSphere.shop_sphere.service;

public class LocationServiceImpl {

}

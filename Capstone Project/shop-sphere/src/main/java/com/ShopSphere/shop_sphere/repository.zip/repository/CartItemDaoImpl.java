package com.ShopSphere.shop_sphere.repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.ShopSphere.shop_sphere.model.CartItem;
import com.ShopSphere.shop_sphere.util.CartItemRowMapper;

@Repository
public class CartItemDaoImpl implements CartItemDao{
	
	private final JdbcTemplate jdbcTemplate;
	
	public CartItemDaoImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public CartItem addItem(CartItem cartItem) {
		String sql = "INSERT INTO cart_items(cart_id, product_id, quantity)"
				+ "VALUES(?, ?, ?)";
		
		KeyHolder keyHolder = new GeneratedKeyHolder();
				
		jdbcTemplate.update(connection ->{
			PreparedStatement ps = connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
				ps.setInt(1, cartItem.getCartId());
				ps.setInt(2, cartItem.getProductId());
				ps.setInt(3, cartItem.getQuantity());
				
				return ps;
			}, keyHolder);
		
		return cartItem;
	}

	@Override
	public Optional<CartItem> findByCartId(int cartId) {
		String sql = "SELECT * from cart_items WHERE  cart_items_id=?";
		
		List<CartItem> result = jdbcTemplate.query(sql, new CartItemRowMapper(), cartId);
		if(result.isEmpty()) return Optional.empty();
		
		return Optional.of(result.get(0));
	}

	@Override
	public int updateItemQuantity(int cartItemId, int quantity) {
		String sql = "UPDATE cart_items SET quantity=? WHERE cart_items_id=?";
		
		return jdbcTemplate.update(sql,
				cartItemId,
				quantity
				);
	}

	@Override
	public int deleteItem(int cartItemId) {
		String sql = "DELETE FROM cart_items WHERE cart_items_id = ?";
		return jdbcTemplate.update(sql,cartItemId);
	}
	
	

}

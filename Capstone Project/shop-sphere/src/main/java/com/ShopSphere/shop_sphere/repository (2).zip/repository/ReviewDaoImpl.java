package com.ShopSphere.shop_sphere.repository;

import com.ShopSphere.shop_sphere.model.Review;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

@Repository
public class ReviewDaoImpl implements ReviewDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public int save(Review review) {
        String sql = "INSERT INTO reviews (user_id, product_id, rating, review_text, status) VALUES (?, ?, ?, ?, ?)";

        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, review.getUserId());
            ps.setInt(2, review.getProductId());
            ps.setInt(3, review.getRating());
            ps.setString(4, review.getReviewText());
            ps.setString(5, review.getStatus());
            return ps;
        }, keyHolder);

        return keyHolder.getKey().intValue(); // returns generated review_id
    }



	@Override
	public List<Review> findByProduct(int productId) {
	    String sql = "SELECT * FROM reviews WHERE product_id = ?";
	    return jdbcTemplate.query(sql, (rs, rowNum) -> mapRowToReview(rs), productId);
	}



	@Override
	public List<Review> findByUser(int userId) {
	    String sql = "SELECT * FROM reviews WHERE user_id = ?";
	    return jdbcTemplate.query(sql, (rs, rowNum) -> mapRowToReview(rs), userId);
	}


    @Override
    public int updateStatus(int reviewId, String status) {
        String sql = "UPDATE reviews SET status = ? WHERE review_id = ?";
        return jdbcTemplate.update(sql, status, reviewId);
    }

    private Review mapRowToReview(java.sql.ResultSet rs) throws java.sql.SQLException {
        Review review = new Review();
        review.setReviewId(rs.getInt("review_id"));
        review.setUserId(rs.getInt("user_id"));
        review.setProductId(rs.getInt("product_id"));
        review.setRating(rs.getInt("rating"));
        review.setReviewText(rs.getString("review_text"));
        review.setStatus(rs.getString("status"));
        review.setCreatedAt(rs.getTimestamp("created_at"));
        return review;
    }
}
package com.ShopSphere.shop_sphere;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopSphereApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.ShopSphere.shop_sphere.exception;

public class OutOfStockException extends RuntimeException{

	public OutOfStockException(String message) {
		super(message);
	}
}


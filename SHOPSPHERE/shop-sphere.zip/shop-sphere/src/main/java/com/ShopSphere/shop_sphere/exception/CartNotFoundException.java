package com.ShopSphere.shop_sphere.exception;

public class CartNotFoundException extends RuntimeException {

	public CartNotFoundException(String message) {
		super(message);
	}
}
